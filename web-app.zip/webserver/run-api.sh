export FLASK_APP=app
export FLASK_ENV=venv
flask run